// function moment() {
//     return {
//         format(time) {
           
//         }
//     }
// }
// moment().format("LT")


setInterval(() => {
    let date = new Date();
    time.innerHtml = `${date.getHourse()}:${date.getMinutes()}`
}, 1000)


