// let a = 1;
// let b = "1";
// console.log(a + b);
// let a = 1;
// let b = "1.2";
// let c = "1.2";
// // console.log(a + +b);
// console.log(a + parseInt(c));
// console.log(a + parseFloat(b));

// console.log(Boolean(" "));
// console.log(Boolean( ));

// let a = 3;
// let b = 2;

// console.log(a % b);


// let a = 3;
// let b = 2;

// console.log(b % a);

// console.log(2 * 2);
// console.log(2 * 2 * 2);
// console.log(2 * 2 * 2 * 2);
// console.log(2 ** 20);

// let a = 3;
// let b = 2;
// console.log((a = b));
// console.log(a == b);
// console.log(a === b);

// let a = 1;
// let b = 2;
// let c = 3;
// c += a
// console.log(c);
// let a = 1;
// a = a--;
// console.log(a);
// console.log(a);
// console.log(typeof("\t \n" - 2));