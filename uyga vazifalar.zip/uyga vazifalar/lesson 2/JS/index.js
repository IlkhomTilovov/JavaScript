// let b = 1;
// let a = "1";

// console.log(b + +a);

// console.log(false === 0);

// console.log(1 !== "0" || (false && "hey"));
// console.log(1 !== "0" || (true && "hey"));


// console.log(1 !== "0" && (false && "hey"));
// console.log(!(1 !== "0" && true && "hey"));


// let age = prompt()

// if (age > 18) {
//     console.log('can open gmail');
// } else {
//     console.log("can't open gmail");
// }


// let temp = "";

// if (temp === "issiq") {
//     console.log("Havo issiq, yengil kiyinib oling!");
// }
// else if (temp === "sovuq") {
//     console.log("Havo sovuq, qalin kiyinib oling!");
// }
// else if (temp === "yomgir") {
//     console.log("Havo yomgir, soyabon olib oling!");
// }
// else if (temp === "qor") {
//     console.log("Havo qor, qalin kiyinib oling!, soyabon olib oling!");
// } else {
//     console.log("nomalum ob havo");
// }

// ==========================
// Mavzu switch 
// let data = ""
// switch (data) {
//     case "yomgir":
//         console.log("bugun yomgir");
//         break;
//     case "qor":
//         console.log("Bugun qor");
//     default:
//         console.log("No data");
//         break;
// }


// for(i=1; i<=10; i++){
//     console.log('hi Web brain');
// }
var sum = 0
for (i = 1; i < 12; i++) {
    // console.log('Sum = ${sum} + ${i}=${(sum += i)}');
    console.log(i);
    i += i 
}