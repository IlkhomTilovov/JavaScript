let sum = 1;
for (i = 1; i <= 10; i = i + 1) {
    console.log(`sum=${sum}+${(sum += 1)}`);
};
if (sum === 10) ;
// let i = 1;
// for (i = 1; i < -10; i - i + 1) {
//     console.log("Hi Webbrain");
// }
// console.log("salom")
