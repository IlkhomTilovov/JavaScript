// for (i = 1; i <= 10; i++) {
//     console.log(`\n${i} - karraliklar\n`);
//     for (let j = 0; j <= 10; j++) {
//         console.log(`${i} * ${j} = ${i * j} `);
//     }
// }

// let a = 1;
// for (let kara = 1; a <= 10; a++) {
//     console.log(`${kara} * ${a} = ${a * kara} `);
// }


// let title;
// title = "Webbrain";
// console.log(title);
// let total = 208
// function get(grade) {
//     let res = grade * 100 / 208
//     console.log(res);
// }

// get(52);
// get(104);


// let title;
// title = "Webbrain";
// console.log(title);
// let total = 208
// function get(grade) {
//     let res = grade * 100 / 208
//     console.log(res);
// }
// get()
// get(52);
// get(104);


// function getName(name){
//     return name;
// }

// console.log(getName("Toshmatov"));


// function get(grade, total) {
//     let res = (grade * 100) / 208;
//     return res;
// }

// console.log(get(200) > 50 ? "passed" : "faild");

// function yoshlar(age) {
//     if (age > 18) {
//         return true;
//     } else {
//         return false;
//     }
// }
// console.log(yoshlar(18));

// function reck(a, b) {
//     if (a < b) {
//         return a;
//     }
//     return b;
// }
// console.log(reck(6, 2));


// function reck(a, b) {
//     let = 1;
//     for (let i = 0; i < b; i++) {
//         num = b * a
//     }
//     console.log(num);
// }
// reck(2, 5);


// function getAvr(){
//     console.log("webbrain");
//     console.log("webbrain");
//     console.log("webbrain");
//     console.log("webbrain");
//     console.log("webbrain");
//     console.log("webbrain");
//     console.log("==============");
// }

// getAvr();
// getAvr();
// console.log("function dan oldin");


// function test(name ="Sardor"){
//     console.log(name);
// }
// test()
// var dd=()=>{

// }
// let dd = "nk"
// console.log(dd);

// console.log(a);
// var a = 10;
// var a=4;
// var a=3;
// console.log(a);
// add()

// function add(){
//     console.log(123);
// }
// add()

// let add=function(){
//     console.log(12432235323);
// }


// For loop=======================================================


// for (let a = 1; a < 11; a += 2) {
//     console.log(a);
// }


// function ffulname(surname = "tilovov", name = "ilxomjon") {
//     name = name.toLocaleLowerCase()
//     surname = surname.toLocaleLowerCase()
//     fylname = name + " " + surname
//     return fylname
// }

// console.log(ffulname("Dilmurod", "Xabibullaev"))



// function chackAge(age) {
//     if (age > 18 || age < 19) {
//         return console.log(true);
//     } else {

//         return console.log('Did parents allow you?');
//     }
// }
// chackAge(80)


// console.log(a);
// var a = 2;


let a = 1;

function box(a = 2) {
    return a
}
console.log(box(2))