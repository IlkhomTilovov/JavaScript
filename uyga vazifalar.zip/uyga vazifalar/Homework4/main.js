// let zero = 0;

// if (zero > 0) {
//     console.log("no'ldan kotta");
// } else if (zero < 0) {
//     console.log("no'ldan kichik");
// } else {
//     console.log("no'lga teng");
// }

// zero > 0
//     ? console.log("nolden katta") : console.log("malumot yo'q");
// zero < 0
//     ? console.log("no'ldan kichik") : console.log("malumot yo'q");
// zero = 0
//     ? console.log("no'lga teng") : console.log("malumot yo'q");
// let zero = 0;

// let zero ="asd";


// zero > 0
//     ? console.log("No'ldan katta") :
//     zero < 0 ? console.log("Noldan kichik") :
//         zero == 0 ? console.log("Nolga teng") :
//             console.log("Number kiritilmadi");


// if(""){
//     console.log("Hello js");
// }
// let a = 2;
// let b = 2;
// let result = (a - b);

// if (result < 4) {
//     console.log("below");
// } else {
//     console.log("over");
// }

// let left = "ECMAScrip1"
// if (left == "ECMAScript"){
//     console.log("Right");
// } else {
//     console.log(`You don't know "EMCAScript"`);
// }


// let left = "other";
// left == "ECMAScrip"
//     ? console.log("Right") :
//     left == "other"
//         ? console.log(`You don't know "EMCAScript"`) :
//         console.log("Xech qanday malumot yo'q");

// let message;
// login = ''
// if (login == 'Employee') {
//     message = 'Hello';
// } else if (login == 'Director') {
//     message = 'Greetings';
// } else if (login == '') {
//     message = 'No login';
// } else {
//     message = ''
// }
// console.log(message);
// let messege;
// let login = 'Director'
// login == 'Employee'
//     ? messege = "Hello" :
//     login == 'Director'
//         ? messege = "Greetings" :
//         login == ''
//             ? messege = 'No login' :
//             messege = ''
// console.log(messege);

// let result;
// a = 2;
// b = 3;
// a + b < 4
//     ? console.log("below") :
//     console.log("over");

// console.log((2 ?? 3) || (1 ?? 4));

// let a=-1;
// if(a>0){
//     console.log(++a);
// }else if(a<0){
//     console.log(a-2);
// }else{
//     console.log(a+10);
// }

// let a = 2;
// let b = -1;
// let c = 3;

// if ((a, b, c) >= 0) {
//     console.log();
// }