let user = {
    name: "John",
    surname: "Smith",
    name: "Pete"
}
// console.log(user);
// console.log(user.name);
delete user.name;
console.log(user.surname);