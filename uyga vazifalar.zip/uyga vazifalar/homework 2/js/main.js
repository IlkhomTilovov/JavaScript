
// // If else bu yerda over chiqadi sababi 1 + "a"ni qoshib b'olmaydi shunga over chiqadi


// // let result;
// // let a=1;
// // let b="a";
// // if (a + b < 4) {
// //     result = "below";
// // } else {
// //     result = "over";
// // }

// // console.log(result);



// // If Else   bu yerda 3 katta 4dan shunga javob below chiqadi

// let result;
// let a=1;
// let b=2;
// if (a + b < 4) {
//     result = "below";
// } else {
//     result = "over";
// }

// console.log(result);

